<?php
// $Id: x27.php,v 1.3 2009/06/09 19:07:06 smk Exp $

$base = array(
  0x00 => NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x10 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x20 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x30 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x40 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x50 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL,
  0x60 => NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x70 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x80 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x90 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xA0 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xB0 => NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL,
  0xC0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xD0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xE0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xF0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
);
